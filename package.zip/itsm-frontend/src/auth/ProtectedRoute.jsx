import { Navigate } from 'react-router-dom'
import { useAuth, homeFor } from './AuthContext'

// Only lets the listed roles in. Everyone else goes to login or to their own home page.
export default function ProtectedRoute({ roles, children }) {
  const { user } = useAuth()
  if (!user) return <Navigate to="/login" replace />
  if (roles && !roles.includes(user.role)) return <Navigate to={homeFor(user.role)} replace />
  return children
}
